// 1. Put the exact file names of your transparent images here
const bgImages = [
    "url('./assets/yuna.webp')",
    "url('./assets/yumi.webp')",
    "url('./assets/yuto.webp')",
    "url('./assets/fam.webp')",
    "url('./assets/italy.webp')",
];

// 2. Get the saved index from localStorage (or start at 0 if it's the first time)
let currentIndex = parseInt(localStorage.getItem('bgIndex')) || 0;

// Just in case you remove an image later and the index is out of bounds, reset it
if (currentIndex >= bgImages.length) {
    currentIndex = 0;
}

// 3. Apply the current image to the background
document.body.style.backgroundImage = bgImages[currentIndex];

// 4. Calculate what the next index should be
let nextIndex = currentIndex + 1;

// If we reached the end of the list, loop back to the first image
if (nextIndex >= bgImages.length) {
    nextIndex = 0;
}

// 5. Save the next index so it's ready for the next time you open a tab
localStorage.setItem('bgIndex', nextIndex);